/**
 * Created by vovk on 06.09.2016.
 */
var app = angular.module('app');
app.controller('bindFormCtrl', ['$scope', bindFormsCtrl]);

function bindFormsCtrl($scope){

}