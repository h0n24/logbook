/**
 * Created by vovk on 13.01.2017.
 */
var app = angular.module('app');
app.controller('mainLogsCtrl', ['$scope','logsHttp', mainLogsCtrl]);

function mainLogsCtrl($scope, logsHttp){

}